-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 27, 2022 at 03:28 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `EMPLOYEE 2 EMPLOYER CONFERENCE SYS`
--

-- --------------------------------------------------------

--
-- CREATING TABLE `admin`
--

CREATE TABLE `admin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- INSERTING DATA FOR `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- CREATING TABLE FOR  `emp`
--

CREATE TABLE `emp` (
  `First Name` varchar(20) NOT NULL,
  `Last Name` varchar(20) NOT NULL,
  `dob` char(20) NOT NULL,
  `EmployeeID` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- INSERTING DATA FOR `emp`
--

INSERT INTO `emp` (`First Name`, `Last Name`, `dob`, `EmployeeID`) VALUES
('unni', 'unni', 'unni krishnan', 'EMP100');

-- --------------------------------------------------------

--
-- CREATING TABLE FOR  `mgrreg`
--

CREATE TABLE `mgrreg` (
  `FirstName` varchar(20) NOT NULL,
  `LastName` varchar(20) NOT NULL,
  `ProjectManager` varchar(20) NOT NULL,
  `projectName` varchar(20) NOT NULL,
  `managerID` char(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- INSERTING DATA FOR `mgrreg`
--

INSERT INTO `mgrreg` (`FirstName`, `LastName`, `ProjectManager`, `projectName`, `managerID`) VALUES
('anoop', 'anoop', 'anoop', 'anoop', 'p01201');

--
-- Indexes for INSERTED tables
--

--
-- ADDING PRIMARY CONSTRAIN FOR table `emp`
--
ALTER TABLE `emp`
  ADD PRIMARY KEY (`EmployeeID`);

--
-- ADDING PRIMARY KEY CONSTRAIN for table `mgrreg`
--
ALTER TABLE `mgrreg`
  ADD PRIMARY KEY (`managerID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
